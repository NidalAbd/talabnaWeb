
<?php $__env->startSection('title', "Create Service Post"); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-users mr-1"></i>
                            <?php echo e(__('Create Service Post')); ?>

                        </h3>
                    </div>
                    <form method="POST" action="<?php echo e(route('service_posts.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="title" class="col-md-4"><?php echo e(__('Title')); ?></label>
                                    <input id="title" type="text" class="form-control col-md-8 <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" value="<?php echo e(old('title')); ?>" required autocomplete="title" autofocus>
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="category" class="col-md-4">Category</label>
                                    <select class="form-control col-md-8" id="category" name="category">
                                        <option value="">Select category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>" data-id="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="description" class="col-md-4"><?php echo e(__('Description')); ?></label>
                                    <textarea id="description" class="form-control col-md-8 <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" required><?php echo e(old('description')); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="sub_category" class="col-md-4">Sub Category</label>
                                    <select class="form-control col-md-8" id="sub_category" name="sub_category">
                                        <option value="">Select subcategory</option>
                                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subcategory->id); ?>" data-category="<?php echo e($subcategory->category_id); ?>"><?php echo e($subcategory->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="location_latitudes" class="col-md-4">Location Latitudes</label>
                                    <input type="text" class="form-control col-md-8" id="location_latitudes" name="location_latitudes">
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="location_longitudes" class="col-md-4">Location Longitudes</label>
                                    <input type="text" class="form-control col-md-8" id="location_longitudes" name="location_longitudes">
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="type" class="col-md-4">Type</label>
                                    <select class="form-control col-md-8" id="type" name="type">
                                        <option value="">Choose</option>
                                        <option value="عرض">Offer</option>
                                        <option value="طلب">Demand</option>
                                    </select>
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="have_badge" class="col-md-4">Badge</label>
                                    <select class="form-control col-md-8" id="have_badge" name="have_badge">
                                        <option value="">Choose</option>
                                        <option value="عادي">Normal</option>
                                        <option value="ذهبي">Golden</option>
                                        <option value="ماسي">Diamond</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="badge_duration" class="col-md-4">Badge Duration</label>
                                    <select class="form-control col-md-8" id="badge_duration" name="badge_duration">
                                        <option value="0" <?php echo e(old('badge_duration') == '0' ? 'selected' : ''); ?>>غير محدد</option>
                                        <option value="1" <?php echo e(old('badge_duration') == '1' ? 'selected' : ''); ?>>One day</option>
                                        <option value="2" <?php echo e(old('badge_duration') == '2' ? 'selected' : ''); ?>>Two days</option>
                                        <option value="3" <?php echo e(old('badge_duration') == '3' ? 'selected' : ''); ?>>Three days</option>
                                        <option value="4" <?php echo e(old('badge_duration') == '4' ? 'selected' : ''); ?>>Four days</option>
                                        <option value="5" <?php echo e(old('badge_duration') == '5' ? 'selected' : ''); ?>>Five days</option>
                                        <option value="6" <?php echo e(old('badge_duration') == '6' ? 'selected' : ''); ?>>Six days</option>
                                        <option value="7" <?php echo e(old('badge_duration') == '7' ? 'selected' : ''); ?>>One week</option>
                                    </select>
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="price_currency" class="col-md-4"><?php echo e(__('Currency')); ?></label>
                                    <select id="price_currency" class="form-control col-md-8 <?php $__errorArgs = ['price_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price_currency" required>
                                        <option value="دولار امريكي" <?php echo e(old('currency') == 'دولار امريكي' ? 'selected' : ''); ?>>&#36; (USD)</option>
                                        <option value="دينار اردني" <?php echo e(old('currency') == 'دينار اردني' ? 'selected' : ''); ?>>&#x4A;&#x44;&#x20; (JOD)</option>
                                        <option value="دينار تونسي" <?php echo e(old('currency') == 'دينار تونسي' ? 'selected' : ''); ?>>&#x62;&#x2E;&#x6E;&#x64; (TND)</option>
                                        <option value="ريال سعودي" <?php echo e(old('currency') == 'ريال سعودي' ? 'selected' : ''); ?>>&#65020; (SAR)</option>
                                        <option value="جنيه مصري" <?php echo e(old('currency') == 'جنيه مصري' ? 'selected' : ''); ?>>&#x62;&#x2E;&#x6C;&#x20; (EGP)</option>
                                        <option value="شيكل فلسطيني" <?php echo e(old('currency') == 'شيكل فلسطيني' ? 'selected' : ''); ?>>&#x20AA; (ILS)</option>
                                        <option value="ليرة لبنانية" <?php echo e(old('currency') == 'ليرة لبنانية' ? 'selected' : ''); ?>>&#x622;&#x2E;&#x641; (LBP)</option>
                                        <option value="درهم إماراتي" <?php echo e(old('currency') == 'درهم إماراتي' ? 'selected' : ''); ?>>&#65020; (AED)</option>
                                        <option value="درهم مغربي" <?php echo e(old('currency') == 'درهم مغربي' ? 'selected' : ''); ?>>&#65020; (MAD)</option>
                                        <option value="دينار كويتي" <?php echo e(old('currency') == 'دينار كويتي' ? 'selected' : ''); ?>>&#x62D;&#x2E;&#x6C;&#x20; (KWD)</option>
                                        <option value="ريال قطري" <?php echo e(old('currency') == 'ريال قطري' ? 'selected' : ''); ?>>&#65020; (QAR)</option>
                                        <option value="دينار بحريني" <?php echo e(old('currency') == 'دينار بحريني' ? 'selected' : ''); ?>>&#x62D;&#x2E;&#x62E; (BHD)</option>
                                        <option value="دينار ليبي" <?php echo e(old('currency') == 'دينار ليبي' ? 'selected' : ''); ?>>&#65020; (LYD)</option>
                                        <option value="ريال عماني" <?php echo e(old('currency') == 'ريال عماني' ? 'selected' : ''); ?>>&#x631;&#x2E;&#x631; (OMR)</option>
                                    </select>
                                    <?php $__errorArgs = ['price_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="price" class="col-md-4">Price</label>
                                    <input type="number" class="form-control col-md-8" id="price" name="price">
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="state" class="col-md-4">State</label>
                                    <select class="form-control col-md-8" id="state" name="state">
                                        <option value="">Select state</option>
                                        <option value="published">Published</option>
                                        <option value="archive">Archive</option>
                                        <option value="not published">Not Published</option>
                                        <option value="rejected">Rejected</option>
                                    </select>
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <input type="hidden" class="form-control" id="view_num" value="0" name="view_num">
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="photos">Photos</label>
                                        <input type="file" name="photos[]" id="photos" accept="image/*" class="form-control-file" multiple required>
                                        <small class="form-text text-muted">Maximum file size: 2.5 MB</small>
                                        <?php $__errorArgs = ['photos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="d-flex justify-content-between">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Back</a>
                                <button type="submit" class="btn btn-primary">Create</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $('#category').change(function(){
                var category_id = $(this).val();
                $.ajax({
                    url: '<?php echo e(route('subcategories.index')); ?>',
                    type: 'GET',
                    data: { category_id: category_id },
                    success: function(response){
                        var subcategories = response.subcategories;
                        var subcategory_select = $('#sub_category');
                        subcategory_select.empty();
                        subcategory_select.append('<option value="">Select subcategory</option>');
                        $.each(subcategories, function(index, subcategory){
                            subcategory_select.append('<option value="'+subcategory.id+'">'+subcategory.name+'</option>');
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/service_posts/create.blade.php ENDPATH**/ ?>