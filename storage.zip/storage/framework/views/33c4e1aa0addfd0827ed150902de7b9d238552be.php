<?php $__env->startSection('title', "General Service Posts"); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-0">
        <div class="row justify-content-center">
            <div class="col-md-12">
                  <div class="d-flex justify-content-end mb-3">
                    <ul class="nav nav-pills ml-auto">
                        <li class="nav-item">
                            <div class="input-group mt-0 input-group-sm">
                               <a href="<?php echo e(route('service_posts.create')); ?>" style="float: right">
                                            <button class="btn btn-primary" onclick="">
                                                <i class="fa fa-user fa-1x"></i>
                                                <?php echo e(__('+ خدمة')); ?>

                                            </button>
                                        </a>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="card">
                    <div class="card-header ">
                        <h3 class="card-title">
                            <i class="fas fa-atom mr-1"></i>
                           General Service Posts
                        </h3>
                        
                    </div>
                    <div class="card-body table-responsive  p-0">
                        <table class="table table-bordered table-striped table-dark table-sm text-center">
                            <thead>
                            <tr class="btn-dark">
                                <th>Title</th>
                                <th>Category</th>
                                <th>User</th>
                                <th>favorites</th>
                                <th>reports</th>
                                <th>views</th>
                                <th>type</th>

                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $servicePosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($post->title); ?></td>
                                    <td><?php echo e($post->category); ?></td>
                                    <td><?php echo e($post->user->user_name); ?></td>
                                    <td><?php echo e($post->favorites_count); ?></td>
                                    <td><?php echo e($post->report_count); ?></td>
                                    <td><?php echo e($post->view_count); ?></td>
                                    <td><?php echo e($post->have_badge); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('service_posts.show', $post->id)); ?>" class="btn btn-sm btn-primary">View</a>
                                        
                                        <a href="<?php echo e(route('service_posts.edit', $post->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                        
                                        
                                        <form action="<?php echo e(route('service_posts.destroy', $post->id)); ?>" method="POST" style="display: inline-block;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this post?')">Delete</button>
                                        </form>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <thead>
                            <tr class="btn-dark">
                                <th>Title</th>
                                <th>Category</th>
                                <th>User</th>
                                <th>favorites</th>
                                <th>reports</th>
                                <th>views</th>
                                <th>type</th>

                                <th>Action</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                                        <div class="card-footer ">
                        <div class="panel-heading" style="display:flex; justify-content:center;align-items:center;">
                            <div class="panel-heading" style="display:flex; justify-content:center;align-items:center;">
                                <?php echo e($servicePosts->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/service_posts/general_index.blade.php ENDPATH**/ ?>