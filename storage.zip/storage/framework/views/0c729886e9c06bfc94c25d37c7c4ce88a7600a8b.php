
<?php $__env->startSection('title', "Users"); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-0">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="d-flex justify-content-end mb-3">
                    <ul class="nav nav-pills ml-auto">
                        <li class="nav-item">
                            <div class="input-group mt-0 input-group-sm">
                                <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success me-2">
                                    <i class="fa fa-user fa-1x"></i>
                                    <?php echo e(__('+ User')); ?>

                                </a>
                                <a href="/app" class="btn btn-info">
                                    <i class="fa fa-user fa-1x"></i>
                                    <?php echo e(__('Roles & Permissions Assignment')); ?>

                                </a>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title mb-0">
                            <i class="fas fa-users mr-1"></i>
                            Users
                        </h3>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover table-striped table-dark text-center">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>State</th>
                                    <th>User</th>
                                    <th>Role</th>
                                    <th>Email</th>
                                    <th>Report</th>
                                    <th>Posts</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(is_countable($Users) && count($Users) > 0): ?>
                                <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->user_name); ?></td>
                                        <td><?php echo e($user->is_active ? 'Active' : 'Inactive'); ?></td>
                                        <td>
                                            <?php if(count($user->roles) > 0): ?>
                                                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($role->name); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->reports_count); ?></td>
                                        <td><?php echo e($user->service_posts_count); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('user.profile', ['user' => $user->id])); ?>" class="btn btn-sm btn-info">Profile</a>
                                            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                            <a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-sm btn-success">View</a>
                                            <a href="<?php echo e(route('palservice_points.create', ['user_id' => $user->id])); ?>" class="btn btn-sm btn-primary">
                                                Add Points
                                            </a>
                                            <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" style="display: inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-sm btn-danger" type="submit"  onclick="return confirm('Are you sure you want to delete this sub user?')">Delete</button>

                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8"><?php echo e(__('No Record')); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer d-flex justify-content-center" style="height: 50px;">
                        <?php echo e($Users->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/users/index.blade.php ENDPATH**/ ?>