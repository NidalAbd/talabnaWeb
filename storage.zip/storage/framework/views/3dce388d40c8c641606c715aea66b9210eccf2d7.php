<?php $__env->startSection('title', "Create Palservice Points"); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-0">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <form method="POST" action="<?php echo e(route('palservice_points.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="card-header"><?php echo e(__('Transfer Palservice Points')); ?></div>
                        <div class="card-body table-responsive p-0">
                            <div class="form-inline m-2">
                                <div class="form-group col-md-4">
                                    <label for="user_id"><?php echo e(__('User ID')); ?></label>
                                    <span class="form-control col-md-12"><?php echo e($user->user_name); ?></span>
                                    <input type="hidden" name="to_user_id" value="<?php echo e($user->id); ?>">
                                    <input type="hidden" name="from_user_id" value="<?php echo e(auth()->user()->id); ?>">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="points"><?php echo e(__('Points')); ?></label>
                                    <input id="points" type="number"
                                           class="form-control col-md-12 <?php $__errorArgs = ['points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="points" value="<?php echo e(old('points')); ?>" required autocomplete="points">
                                    <?php $__errorArgs = ['points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="type">type</label>
                                    <select class="form-control col-md-12" id="type" name="type" required>
                                    <?php if(auth()->user()->hasPermission('grant_points')): ?>
                                        <option value="admin_grant">admin grant</option>
                                            <option value="transfer">transfer</option>
                                    <?php else: ?>
                                        <option value="transfer">transfer</option>
                                    <?php endif; ?>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <div class="card-footer col-md-12">
                            <div class="row justify-content-around">
                                <div class="form-group col-md-4">
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary ">Back</a>
                                </div>
                                <div class="form-group col-md-4">

                                </div>
                                <div class="form-group col-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Create')); ?>

                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/palservice_points/create.blade.php ENDPATH**/ ?>