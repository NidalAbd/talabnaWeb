
<?php $__env->startSection('title', "User"); ?>
<?php $__env->startSection('content'); ?>
<div class="p-0">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-users mr-1"></i>
                        <h3 class="float-left">Points</h3>
                    </h3>
                    <div class="card-tools">
                        <ul class="nav nav-pills ml-auto">
                            <li class="nav-item">
                                <div class="input-group mt-0 input-group-sm">


                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-bordered table-striped table-dark table-sm text-center">
                        <thead>
                            <tr class="btn-dark">
                                <th>No</th>
                                <th>User</th>
                                <th>Role</th>
                                <th>Points</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if(is_countable($palservicePoints) && count($palservicePoints) > 0): ?>
                            <?php $__currentLoopData = $palservicePoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $palservicePoint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($palservicePoint->id); ?></td>
                                    <td><?php echo e($palservicePoint->user?->name ?? 'Passed User'); ?></td>
                                    <td>
                                        <?php if($palservicePoint->user && count($palservicePoint->user->roles) > 0): ?>
                                            <?php $__currentLoopData = $palservicePoint->user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($role->name ?? 'Passed User'); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            Passed User
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($palservicePoint->point); ?></td>
                                    <td>






                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5"><?php echo e(__('No Records')); ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="btn-dark">
                                <th>No</th>
                                <th>User</th>
                                <th>Role</th>
                                <th>Points</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="card-footer" style="height: 50px;"> <!-- Adjust height as needed -->
                    <div class="m-0" style="display: flex; justify-content: center;">
                        <?php echo e($palservicePoints->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Projects\Laravel\TalabnaNew\resources\views/palservice_points/index.blade.php ENDPATH**/ ?>