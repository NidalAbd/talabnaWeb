
<?php $__env->startSection('title', "Statistics"); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-0">
        <div class="row justify-content-center">
            <div class="col-md-12">
               <div class="container-fluid">
                    <h2 class="mb-4"><strong>Statistics</strong></h2>
                    <div class="row">
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-primary text-white">
                                <div class="inner">
                                    <h3><?php echo e($purchaseRequests); ?></h3>
                                    <p>Purchase Requests</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo e(route('purchase_points.index')); ?>" class="small-box-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-success text-white">
                                <div class="inner">
                                    <h3><?php echo e($user); ?></h3>
                                    <p><?php echo e(__('User')); ?></p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                <a href="<?php echo e(route('users.index')); ?>" class="small-box-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-warning text-white">
                                <div class="inner">
                                    <h3>65</h3>
                                    <p>Unique Visitors</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-pie-graph"></i>
                                </div>
                                <a href="#" class="small-box-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-info text-white">
                                <div class="inner">
                                    <h3><?php echo e($allDiamond); ?></h3>
                                    <p>Diamond</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo e(route('purchase_points.index')); ?>" class="small-box-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-danger text-white">
                                <div class="inner">
                                    <h3><?php echo e($allGolden); ?></h3>
                                    <p><?php echo e(__('Golden')); ?></p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                <a href="<?php echo e(route('users.index')); ?>" class="small-box-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-secondary text-white">
                                <div class="inner">
                                    <h3><?php echo e($allNormal); ?></h3>
                                    <p>Normal</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-pie-graph"></i>
                                </div>
                                <a href="#" class="small-box-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box gradient-lightblue text-dark">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-check-circle"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Active')); ?></span>
                                    <span class="info-box-number"><?php echo e($allGeneral); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box gradient-lightblue text-dark">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-ghost"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Banned')); ?></span>
                                    <span class="info-box-number"><?php echo e($allGeneral); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box gradient-lightblue text-dark">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-check-circle"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Not Active')); ?></span>
                                    <span class="info-box-number"><?php echo e($allGeneral); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box gradient-lightblue text-dark">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-ban"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Rejected')); ?></span>
                                    <span class="info-box-number"><?php echo e($allGeneral); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-purple text-white mb-3">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-tools"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('All')); ?></span>
                                    <span class="info-box-number"><?php echo e($allService); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-orange text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-ghost"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('General Service')); ?></span>
                                    <span class="info-box-number"><?php echo e($allGeneral); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-teal text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-building"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Real Estate')); ?></span>
                                    <span class="info-box-number"><?php echo e($allRealState); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-pink text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-joint"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Jobs')); ?></span>
                                    <span class="info-box-number"><?php echo e($allJobs); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-warning text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-car"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Cars')); ?></span>
                                    <span class="info-box-number"><?php echo e($allCar); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-lightgreen text-white mb-3">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-phone"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Devices')); ?></span>
                                    <span class="info-box-number"><?php echo e($allPhone); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix hidden-md-up"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/admin/statistics.blade.php ENDPATH**/ ?>