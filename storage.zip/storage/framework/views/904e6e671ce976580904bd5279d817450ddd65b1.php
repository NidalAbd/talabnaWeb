
<?php $__env->startSection('title', "Categories"); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-0">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header ">
                        <h3 class="card-title">
                            <i class="fas fa-list mr-1"></i>
                            <h3 class="float-left">Categories</h3>
                        </h3>
                        <div class="card-tools">
                            <ul class="nav nav-pills ml-auto">
                                <li class="nav-item">
                                    <div class="input-group mt-0 input-group-sm" >
                                        
                                        
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="card-body table-responsive p-0">
                        <table class="table table-bordered table-striped table-dark table-sm text-center" >
                            <thead>
                            <tr class="btn-dark " >
                                <th>id</th>
                                <th>image</th>
                                <th>Category Name</th>
                                <th>Subcategories Count</th>
                                <th>Service Posts Count</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php if(is_countable($categories) && count($categories) > 0): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($category->id); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $category->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <img src="<?php echo e($photo->src); ?>" width="50" height="50">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->sub_categories_with_service_posts_count); ?></td>
                                        <td><?php echo e($category->service_posts_count); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3"><?php echo e(__('No data available')); ?></td>
                                </tr>
                            </tbody>

                            <?php endif; ?>
                            <tr class="btn-dark " >
                                <th>id</th>
                                <th>image</th>
                                <th>Category Name</th>
                                <th>Subcategories Count</th>
                                <th>Service Posts Count</th>
                            </tr>
                        </table>
                    </div>
                     <div class="card-footer" style="height: 50px;"> <!-- Adjust height as needed -->
                            <div class="m-0" style="display: flex; justify-content: center;">
                                <?php echo e($categories->links()); ?>

                            </div>
                     </div>
                   
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/categories/index.blade.php ENDPATH**/ ?>