<?php
    $user = auth()->user()
?>
    <!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name')); ?> <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" href="<?php echo e(asset('img/logo.ico')); ?>">

    <!-- jQuery and Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css"/>

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- App scripts and styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>

    <style>

        /* Dark mode styles */
        body.dark-mode {
            background-color: #282c35;
            color: #ffffff;
            filter: invert(1); /* Invert colors for dark mode */
        }

        /* Exclude specific images from inversion */
        body.dark-mode img.no-invert {
            filter: invert(0) !important; /* Reset inversion for specific images */
        }

        /* Dark mode toggle button styles */
        #darkModeToggle {
            cursor: pointer;
            border: none;
            background: none;
        }
        /* Icon styles */
        #darkModeToggle i {
            font-size: 1rem; /* Adjust the size of the icon */
            filter: invert(0) !important; /* Reset the inversion for the icon */
        }

/* Custom CSS for Gradient Backgrounds */
.gradient-primary {
    background: linear-gradient(135deg, #007bff, #6f42c1);
}
.gradient-warning {
    background: linear-gradient(135deg, #ffc107, #fd7e14);
}
.gradient-secondary {
    background: linear-gradient(135deg, #6c757d, #343a40);
}
.gradient-danger {
    background: linear-gradient(135deg, #dc3545, #e83e8c);
}
.gradient-info {
    background: linear-gradient(135deg, #17a2b8, #6610f2);
}
.gradient-success {
    background: linear-gradient(135deg, #28a745, #20c997);
}
.gradient-purple {
    background: linear-gradient(135deg, #6f42c1, #6610f2);
}
.gradient-orange {
    background: linear-gradient(135deg, #fd7e14, #e83e8c);
}
.gradient-teal {
    background: linear-gradient(135deg, #20c997, #17a2b8);
}
.gradient-pink {
    background: linear-gradient(135deg, #e83e8c, #fd7e14);
}
.gradient-lime {
    background: linear-gradient(135deg, #cddc39, #ffc107);
}
.gradient-lightgreen {
    background: linear-gradient(135deg, #8bc34a, #4caf50);
}
.gradient-lightblue {
    background: linear-gradient(135deg, #ADD8E6, #87CEEB);
}



    </style>
</head>

<body class="hold-transition sidebar-mini">

<div id="app">
    <div class="wrapper">
            <nav class="main-header navbar navbar-expand-lg sidebar-light-dark border-0">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#">
                        <i class="fa fa-bars fa-2x"></i>
                    </a>
                </li>
            </ul>

            <form class="form-inline ml-3">
                <div class="input-group input-group-sm">
                    <input class="form-control form-control-navbar" type="search" placeholder="Search"
                           aria-label="Search">
                    <div class="input-group-append">
                        <button class="btn btn-navbar" type="submit">
                            <i class="fa fa-search fa-lg"></i>
                        </button>
                    </div>
                </div>
            </form>

            <ul class="navbar-nav ml-auto">
                <li class="nav-item d-flex align-items-center">
                    <span class=""><strong><?php echo e(auth()->user()->pointsBalance ?? 0); ?></strong></span>
                    <a href="<?php echo e(route('purchase_points.create')); ?>" class="btn btn-sm btn-primary ml-3">
                        <i class="fas fa-plus"></i>
                    </a>
                </li>
                &nbsp;&nbsp;&nbsp;

                <li class="nav-item">
                                <button id="darkModeToggle" class="nav-link btn btn-link">
                                    <i class="fas fa-moon"></i>
                                </button>
                </li>
                 <li class="nav-item d-flex align-items-center">
                <a href="<?php echo e(route('post.profile', auth()->user()->id)); ?>" class="nav-link">
                    <span class="mr-2"><?php echo e(auth()->user()->user_name ?? ''); ?></span>
                    <?php if($user && $user->photos && $user->photos->count() > 0): ?>
                        <img src="<?php echo e(asset('storage/' . $user->photos->first()->src)); ?>"
                             class="img-circle elevation-2 mr-2 text-black"
                             alt="Profile Picture"
                             style="width: 30px; height: 30px; border-radius: 50%; object-fit: cover;">
                    <?php else: ?>
                        <img src="<?php echo e(asset('storage/photos/avatar1.png')); ?>"
                             class="img-circle elevation-2 mr-2"
                             alt="Profile Picture"
                             style="width: 30px; height: 30px; border-radius: 50%; object-fit: cover;">
                    <?php endif; ?>
                   
                </a>
            </li>
            </ul>
        </nav>
        <aside class="main-sidebar  sidebar-light-dark">
            <a href="/" class=" nav-pills nav-sidebar flex-column d-flex justify-content-center align-items-center">
                <img src="/img/logo.ico" class="brand img-circle elevation-2" style="opacity: .8; height: 47px;" alt=""><strong>
                </strong>
            </a>
            <!-- Sidebar -->
            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">
                        <?php if (app('laratrust')->isAbleTo('view_statistics')) : ?>
                        <li class="nav-item has-treeview menu-open">
                            <a href="<?php echo e(route('statistics.index')); ?>" class="nav-link ">
                                <i class="nav-icon fas fa-tachometer-alt green"></i>
                                <p class="white text-bold"> Dashboard</p>
                            </a>
                        </li>
                        <?php endif; // app('laratrust')->permission ?>
                        <?php if (app('laratrust')->isAbleTo('user_index')) : ?>
                        <li class="nav-item has-treeview">
                            <a href="#" class="nav-link active">
                                <i class="nav-icon fas fa-cogs"></i>
                                <p>
                                    Admin Management
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                           <?php if (app('laratrust')->isAbleTo('user_index')) : ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('users.index')); ?>" class="nav-link">
                                        <i class="fas fa-users-cog nav-icon red"></i>
                                        <p>Users</p>
                                    </a>
                                </li>
                                <?php endif; // app('laratrust')->permission ?>
                                <?php if (app('laratrust')->isAbleTo('purchase_index')) : ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('purchase_points.index')); ?>" class="nav-link">
                                        <i class="fas fa-users-cog nav-icon blue"></i>
                                        <p>orders</p>
                                    </a>
                                </li>
                                <?php endif; // app('laratrust')->permission ?>
                                <?php if (app('laratrust')->isAbleTo('purchase_index')) : ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('palservice_points.index')); ?>" class="nav-link">
                                        <i class="fas fa-users-cog nav-icon green"></i>
                                        <p>Owned Point</p>
                                    </a>
                                </li>
                                <?php endif; // app('laratrust')->permission ?>
                                <?php if (app('laratrust')->isAbleTo('purchase_index')) : ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('point_transactions.index')); ?>" class="nav-link">
                                        <i class="fas fa-users-cog nav-icon orange"></i>
                                        <p>Transaction</p>
                                    </a>
                                </li>
                                <?php endif; // app('laratrust')->permission ?>
                                  <li class="nav-item">
                                    <a href="<?php echo e(route('reports.index')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-flag red"></i>
                                        <p class="white text-bold">Reports</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <?php endif; // app('laratrust')->permission ?>
                        <?php if (app('laratrust')->isAbleTo('show_profile')) : ?>
                        <?php endif; // app('laratrust')->permission ?>
                        <?php if(auth()->check()): ?>
                             
                                <?php if (app('laratrust')->isAbleTo('user_index')) : ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('service_posts.index')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-home "></i>
                                        <p class="white text-bold">All Service</p>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('job.index')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-user-secret "></i>
                                        <p class="white text-bold">Jobs</p>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('phone.index')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-phone-square"></i>
                                        <p class="white text-bold">Devices</p>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('realStat.index')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-building"></i>
                                        <p class="white text-bold">Real Estate</p>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('car.index')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-car"></i>
                                        <p class="white text-bold">Cars</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('generals.index')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-shopping-basket"></i>
                                        <p class="white text-bold">General</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('categories.index')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-shopping-basket"></i>
                                        <p class="white text-bold">Category</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('indexSubCategory.index')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-shopping-basket"></i>
                                        <p class="white text-bold">SubCategory</p>
                                    </a>
                                </li>
                                <?php endif; // app('laratrust')->permission ?>
                           
                            <li class="nav-item">
                                <a href="<?php echo e(route('post.profile', auth()->user()->id)); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-user-circle"></i>
                                    <p class="white text-bold">Posts Table</p>
                                </a>
                            </li>













                        <li class="nav-item">
                            <a href="<?php echo e(route('users.edit',$user->id)); ?>" class="nav-link">
                                <i class="nav-icon fas fa-cog"></i>
                                <p class="white text-bold">User setting</p>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="true">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();
                             ">
                                <i class="nav-icon fas fa-power-off red"></i>
                                <p>Logout</p>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                      style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>
        <!-- Content Wrapper. Contains page content -->

            <div class="content-wrapper sidebar-light-dark">
            <!-- Content Header (Page header) -->
            <!-- /.content-header -->
            <div class="py-1">

                <!-- Content Header (Page header) -->
                <div class="content-header">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-12">
                                <ol class="breadcrumb float-sm-left">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>

                                </ol>
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                    </div><!-- /.container-fluid -->
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <div class="content">
                    <div class="container-fluid">
                        <?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div><!-- /.container-fluid -->
                </div>
            </div>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <!-- Main Footer -->
            <footer class="main-footer sidebar-light-dark border-0">
            <!-- To the right -->

            <!-- Default to the left -->
            <strong><?php echo e(config('app.name', 'PalService')); ?> Copyright &copy; 2023-2024

            </strong>
        </footer>
    </div>
</div>

<!-- ./wrapper -->
<?php echo $__env->yieldContent('script'); ?>
</body>

<script>
    $(document).ready(function() {
        // Check if the user has a preferred color scheme
        const prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)");

        // Set the initial mode based on user preference
        if (prefersDarkScheme.matches) {
            toggleDarkMode(true);
        }

        // Toggle dark mode on button click
        $("#darkModeToggle").click(function() {
            const isDarkMode = $("body").hasClass("dark-mode");
            toggleDarkMode(!isDarkMode);
        });

        // Function to toggle dark mode
        function toggleDarkMode(enable) {
            // Enable or disable dark mode class on the body
            $("body").toggleClass("dark-mode", enable);

            // Store the user preference in local storage
            localStorage.setItem("darkMode", enable ? "enabled" : "disabled");
        }
    });
</script>
<!-- Include this script in your HTML -->
<script>
    // Check if the user has a preference stored
    const darkModePreference = localStorage.getItem('darkMode');

    // Apply dark mode if the preference is set
    if (darkModePreference === 'enabled') {
        document.body.classList.add('dark-mode');
    }

    // Toggle dark mode on button click
    document.getElementById('darkModeToggle').addEventListener('click', function () {
        // Toggle dark mode class on body
        document.body.classList.toggle('dark-mode');

        // Update user preference in localStorage
        const isDarkModeEnabled = document.body.classList.contains('dark-mode');
        localStorage.setItem('darkMode', isDarkModeEnabled ? 'enabled' : 'disabled');
    });
</script>

<!-- jQuery from CDN -->

</html>

<?php /**PATH H:\Projects\Laravel\TalabnaNew\resources\views/dashboard.blade.php ENDPATH**/ ?>