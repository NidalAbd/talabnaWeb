<?php $__env->startSection('title', "Reports"); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-0">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header ">
                        <h3 class="card-title">
                            <i class="fas fa-users mr-1"></i>
                            Reports
                        </h3>
                        <div class="card-tools">
                            <ul class="nav nav-pills ml-auto">

                            </ul>
                        </div>
                    </div>

                    <div class="card-body table-responsive p-0">
                        <table class="table table-bordered table-sm text-center">
                            <thead>
                            <tr class="btn-dark">
                                <th>ID</th>
                                <th>Type</th>
                                <th>Number of Reports</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if($reports->count() > 0): ?>
                                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($group->reportable): ?>
                                        <?php
                                            $reportable = $group->reportable;
                                            $routeName = $group->reportable_type == \App\Models\User::class ? 'user' : 'service_posts';
                                        ?>

                                        <tr>
                                            <td><?php echo e($reportable->id); ?></td>
                                            <td>
                                                <?php if($group->reportable_type == \App\Models\User::class): ?>
                                                    User: <?php echo e($reportable->name); ?>

                                                <?php else: ?>
                                                    Service Post: <?php echo e($reportable->title); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($group->total); ?></td>
                                            <td>
                                                <a href="<?php echo e(route($routeName.'.show', $reportable->id)); ?>" class="btn btn-sm btn-primary">View</a>
                                                <form action="<?php echo e(route($routeName.'.destroy', $reportable->id)); ?>" method="POST" style="display: inline-block;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this <?php echo e($group->reportable_type == \App\Models\User::class ? 'user' : 'service_post'); ?>?')">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4"><?php echo e(__('No Record')); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                            <tr class="btn-dark">
                                <th>ID</th>
                                <th>Type</th>
                                <th>Number of Reports</th>
                                <th>Action</th>
                            </tr>
                        </table>

                    </div>
                                          <div class="card-footer" style="height: 50px;"> <!-- Adjust height as needed -->
                            <div class="m-0" style="display: flex; justify-content: center;">
                                <?php echo e($reports->links()); ?>

                            </div>
                     </div>

                   
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/admin/report.blade.php ENDPATH**/ ?>