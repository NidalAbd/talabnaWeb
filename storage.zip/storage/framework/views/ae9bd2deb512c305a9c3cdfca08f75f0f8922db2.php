
<?php $__env->startSection('title', "Edit Service Post"); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-users mr-1"></i>
                            <?php echo e(__('Edit Service Post')); ?>

                        </h3>
                    </div>
                    <form action="<?php echo e(route('service_posts.update', $servicePost)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="card-body">
                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="title" class="col-md-4">Title</label>
                                    <input type="text" name="title" class="form-control col-md-8 <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('title', $servicePost->title)); ?>" required autofocus>
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="category" class="col-md-4">Category</label>
                                    <select class="form-control col-md-8" id="category" name="category">
                                        <option value="">Select category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>" <?php if($category->id == $servicePost->categories_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="description" class="col-md-4"><?php echo e(__('Description')); ?></label>
                                    <textarea id="description" class="form-control col-md-8 <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" required><?php echo e(old('description', $servicePost->description)); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="sub_category" class="col-md-4">Sub Category</label>
                                    <select class="form-control col-md-8" id="sub_category" name="sub_category">
                                        <option value="">Select subcategory</option>
                                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subcategory->id); ?>" data-category="<?php echo e($subcategory->category_id); ?>" <?php if($subcategory->id == $servicePost->sub_categories_id): ?> selected <?php endif; ?>><?php echo e($subcategory->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="location_latitudes" class="col-md-4">Location Latitudes</label>
                                    <input type="text" class="form-control col-md-8" id="location_latitudes" name="location_latitudes" value="<?php echo e(old('location_latitudes', $servicePost->location_latitudes)); ?>">
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="location_longitudes" class="col-md-4">Location Longitudes</label>
                                    <input type="text" class="form-control col-md-8" id="location_longitudes" name="location_longitudes" value="<?php echo e(old('location_longitudes', $servicePost->location_longitudes)); ?>">
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="type" class="col-md-4">Type</label>
                                    <select class="form-control col-md-8" id="type" name="type">
                                        <option value="">Choose</option>
                                        <option value="عرض" <?php echo e(old('type', $servicePost->type) == 'عرض' ? 'selected' : ''); ?>>Offer</option>
                                        <option value="طلب" <?php echo e(old('type', $servicePost->type) == 'طلب' ? 'selected' : ''); ?>>Demand</option>
                                    </select>
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="price_currency" class="col-md-4"><?php echo e(__('Currency')); ?></label>
                                    <select id="price_currency" class="form-control col-md-8 <?php $__errorArgs = ['price_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price_currency" required>
                                        <option value="دولار امريكي" <?php echo e(old('price_currency', $servicePost->price_currency) == 'دولار امريكي' ? 'selected' : ''); ?>>&#36; (USD)</option>
                                        <option value="دينار اردني" <?php echo e(old('price_currency', $servicePost->price_currency) == 'دينار اردني' ? 'selected' : ''); ?>>&#x4A;&#x44;&#x20; (JOD)</option>
                                        <option value="دينار تونسي" <?php echo e(old('price_currency', $servicePost->price_currency) == 'دينار تونسي' ? 'selected' : ''); ?>>&#x62;&#x2E;&#x6E;&#x64; (TND)</option>
                                        <option value="ريال سعودي" <?php echo e(old('price_currency', $servicePost->price_currency) == 'ريال سعودي' ? 'selected' : ''); ?>>&#65020; (SAR)</option>
                                        <option value="جنيه مصري" <?php echo e(old('price_currency', $servicePost->price_currency) == 'جنيه مصري' ? 'selected' : ''); ?>>&#x62;&#x2E;&#x6C;&#x20; (EGP)</option>
                                        <option value="شيكل فلسطيني" <?php echo e(old('price_currency', $servicePost->price_currency) == 'شيكل فلسطيني' ? 'selected' : ''); ?>>&#x20AA; (ILS)</option>
                                        <option value="ليرة لبنانية" <?php echo e(old('price_currency', $servicePost->price_currency) == 'ليرة لبنانية' ? 'selected' : ''); ?>>&#x622;&#x2E;&#x641; (LBP)</option>
                                        <option value="درهم إماراتي" <?php echo e(old('price_currency', $servicePost->price_currency) == 'درهم إماراتي' ? 'selected' : ''); ?>>&#65020; (AED)</option>
                                        <option value="درهم مغربي" <?php echo e(old('price_currency', $servicePost->price_currency) == 'درهم مغربي' ? 'selected' : ''); ?>>&#65020; (MAD)</option>
                                        <option value="دينار كويتي" <?php echo e(old('price_currency', $servicePost->price_currency) == 'دينار كويتي' ? 'selected' : ''); ?>>&#x62D;&#x2E;&#x6C;&#x20; (KWD)</option>
                                        <option value="ريال قطري" <?php echo e(old('price_currency', $servicePost->price_currency) == 'ريال قطري' ? 'selected' : ''); ?>>&#65020; (QAR)</option>
                                        <option value="دينار بحريني" <?php echo e(old('price_currency', $servicePost->price_currency) == 'دينار بحريني' ? 'selected' : ''); ?>>&#x62D;&#x2E;&#x62E; (BHD)</option>
                                        <option value="دينار ليبي" <?php echo e(old('price_currency', $servicePost->price_currency) == 'دينار ليبي' ? 'selected' : ''); ?>>&#65020; (LYD)</option>
                                        <option value="ريال عماني" <?php echo e(old('price_currency', $servicePost->price_currency) == 'ريال عماني' ? 'selected' : ''); ?>>&#x631;&#x2E;&#x631; (OMR)</option>
                                    </select>
                                    <?php $__errorArgs = ['price_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="price" class="col-md-4">Price</label>
                                    <input type="number" class="form-control col-md-8" id="price" name="price" value="<?php echo e(old('price', $servicePost->price)); ?>">
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <label for="state" class="col-md-4">State</label>
                                    <select class="form-control col-md-8" id="state" name="state">
                                        <option value="">Select state</option>
                                        <option value="published" <?php echo e(old('state', $servicePost->state) == 'published' ? 'selected' : ''); ?>>Published</option>
                                        <option value="archive" <?php echo e(old('state', $servicePost->state) == 'archive' ? 'selected' : ''); ?>>Archive</option>
                                        <option value="not published" <?php echo e(old('state', $servicePost->state) == 'not published' ? 'selected' : ''); ?>>Not Published</option>
                                        <option value="rejected" <?php echo e(old('state', $servicePost->state) == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                    </select>
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <input type="hidden" class="form-control" id="view_num" value="<?php echo e(old('view_num', $servicePost->view_num)); ?>" name="view_num">
                                </div>
                            </div>

                            <div class="row mb-1">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="photos">Photos</label>
                                        <input type="file" name="photos[]" id="photos" accept="image/*" class="form-control-file" multiple>
                                        <small class="form-text text-muted">Maximum file size: 2.5 MB</small>
                                        <?php $__errorArgs = ['photos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php if($servicePost->photos->count() > 0): ?>
    <div class="mt-4">
        <label for="current_photos">Current Photos:</label>
        <div class="row">
            <?php $__currentLoopData = $servicePost->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 d-flex flex-column align-items-center">
                    <img src="<?php echo e(asset('storage/'.$photo->src)); ?>" class="img-thumbnail mb-2">
                    <label for="delete_photo_<?php echo e($photo->id); ?>" class="form-check-label">
                        <input type="checkbox" name="delete_photos[]" id="delete_photo_<?php echo e($photo->id); ?>" value="<?php echo e($photo->id); ?>" class="form-check-input"> Delete
                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="d-flex justify-content-between">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Back</a>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $('#category').change(function(){
                var category_id = $(this).val();
                $.ajax({
                    url: '<?php echo e(route('subcategories.index')); ?>',
                    type: 'GET',
                    data: { category_id: category_id },
                    success: function(response){
                        var subcategories = response.subcategories;
                        var subcategory_select = $('#sub_category');
                        subcategory_select.empty();
                        subcategory_select.append('<option value="">Select subcategory</option>');
                        $.each(subcategories, function(index, subcategory){
                            subcategory_select.append('<option value="'+subcategory.id+'">'+subcategory.name+'</option>');
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/service_posts/edit.blade.php ENDPATH**/ ?>