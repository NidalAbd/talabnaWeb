<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" sizes="64x64" href="<?php echo e(asset('storage/favicon-32x32.png')); ?>">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="icon"  href="<?php echo e(asset('img/logo.ico')); ?>">


    <!-- Scripts -->
    <!-- jQuery and Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Other body tags -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

    <!-- App scripts and styles -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css"/>
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
 <style>
/* Custom CSS for Gradient Backgrounds */
.gradient-primary {
    background: linear-gradient(135deg, #007bff, #6f42c1);
}
.gradient-warning {
    background: linear-gradient(135deg, #ffc107, #fd7e14);
}
.gradient-secondary {
    background: linear-gradient(135deg, #6c757d, #343a40);
}
.gradient-danger {
    background: linear-gradient(135deg, #dc3545, #e83e8c);
}
.gradient-info {
    background: linear-gradient(135deg, #17a2b8, #6610f2);
}
.gradient-success {
    background: linear-gradient(135deg, #28a745, #20c997);
}
.gradient-purple {
    background: linear-gradient(135deg, #6f42c1, #6610f2);
}
.gradient-orange {
    background: linear-gradient(135deg, #fd7e14, #e83e8c);
}
.gradient-teal {
    background: linear-gradient(135deg, #20c997, #17a2b8);
}
.gradient-pink {
    background: linear-gradient(135deg, #e83e8c, #fd7e14);
}
.gradient-lime {
    background: linear-gradient(135deg, #cddc39, #ffc107);
}
.gradient-lightgreen {
    background: linear-gradient(135deg, #8bc34a, #4caf50);
}

 </style>
</head>
<body class="antialiased" >
<!-- Navigation Bar -->
<nav class="navbar navbar-expand-md  shadow-sm bg-dark" >
    <div class="container justify-content-between" style=" color: lavender; ">
        <div>
            <a class="navbar-brand" style="color: white;" href="<?php echo e(url('userAllServiceIndex')); ?>">
                <?php echo e(config('app.name', 'Laravel')); ?>

            </a>
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <div class="mx-auto"> <!-- mx-auto centers the content -->
                <div id="subcategory-container" class="d-flex flex-wrap mt-2" style="display: none;">
                    <a href="/" class="btn btn-md mx-3 category-link" style="color: white;" data-subcategories="subcategory2">All</a>
                    <a href="/" class="btn btn-md mx-3 category-link" style="color: white;" data-subcategories="subcategory1">Jobs</a>
                    <a href="/" class="btn btn-md mx-3 category-link" style="color: white;" data-subcategories="subcategory2">Devices</a>
                    <a href="/" class="btn btn-md mx-3 category-link" style="color: white;" data-subcategories="subcategory3">Real estate</a>
                    <a href="/" class="btn btn-md mx-3 category-link" style="color: white;" data-subcategories="subcategory4">Cars</a>
                    <a href="/" class="btn btn-md mx-3 category-link" style="color: white;" data-subcategories="subcategory5">Service</a>
                </div>
            </div>
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ms-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" style="color: white;" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" style="color: white;"
                               href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link"  style="color: white;" href="<?php echo e(route('home')); ?>"><?php echo e(__('DashBoard')); ?></a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link"  style="color: white;" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>


                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div id="subcategory-container" class="d-flex flex-wrap mt-2" style="display: none;">
    <!-- Subcategories/tags will be added here dynamically -->
</div>
<!-- Main Content Container -->
<div class="container">
    <div class="p-0">
        <div class="row justify-content-center">
<!--            <div class="d-flex justify-content-center">
                <h2><strong>Statistics only Displayed and the Data Viewed Only by Flutter end Point</strong></h2>
            </div>-->
            <div class="col-md-12">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box gradient-primary text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-check-circle"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Active')); ?></span>
                                    <span class="info-box-number"><?php echo e($allGeneral); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box gradient-warning text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-ghost"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Banned')); ?></span>
                                    <span class="info-box-number"><?php echo e($allGeneral); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box gradient-secondary text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-check-circle"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Not Active')); ?></span>
                                    <span class="info-box-number"><?php echo e($allGeneral); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box gradient-danger text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-ban"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Rejected')); ?></span>
                                    <span class="info-box-number"><?php echo e($allGeneral); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-info text-white">
                                <div class="inner">
                                    <h3><?php echo e($purchaseRequests); ?></h3>
                                    <p>Purchase Requests</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="#" class="small-box-footer bg-dark text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-success text-white">
                                <div class="inner">
                                    <h3><?php echo e($users); ?></h3>
                                    <p><?php echo e(__('User')); ?></p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                <a href="#" class="small-box-footer bg-dark text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-warning text-white">
                                <div class="inner">
                                    <h3>65</h3>
                                    <p>Unique Visitors</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-pie-graph"></i>
                                </div>
                                <a href="#" class="small-box-footer bg-dark text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-primary text-white">
                                <div class="inner">
                                    <h3><?php echo e($allDiamond); ?></h3>
                                    <p>Diamond</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="#" class="small-box-footer bg-dark text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-success text-white">
                                <div class="inner">
                                    <h3><?php echo e($allGolden); ?></h3>
                                    <p><?php echo e(__('Golden')); ?></p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                <a href="#" class="small-box-footer bg-dark text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-6">
                            <div class="small-box gradient-secondary text-white">
                                <div class="inner">
                                    <h3><?php echo e($allNormal); ?></h3>
                                    <p>Normal</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-pie-graph"></i>
                                </div>
                                <a href="#" class="small-box-footer bg-dark text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-purple text-white mb-3">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-tools"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('All')); ?></span>
                                    <span class="info-box-number"><?php echo e($allService); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-orange text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-ghost"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('General Service')); ?></span>
                                    <span class="info-box-number"><?php echo e($allGeneral); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-teal text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-building"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Real Estate')); ?></span>
                                    <span class="info-box-number"><?php echo e($allRealState); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-pink text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-joint"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Jobs')); ?></span>
                                    <span class="info-box-number"><?php echo e($allJobs); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-lime text-white">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-car"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Cars')); ?></span>
                                    <span class="info-box-number"><?php echo e($allCar); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="info-box gradient-lightgreen text-white mb-3">
                                <span class="info-box-icon bg-dark elevation-1"><i class="fas fa-phone"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e(__('Devices')); ?></span>
                                    <span class="info-box-number"><?php echo e($allPhone); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix hidden-md-up"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


</body>
</html>


































































































<?php /**PATH H:\Projects\Laravel\TalabnaNew\resources\views/welcome.blade.php ENDPATH**/ ?>