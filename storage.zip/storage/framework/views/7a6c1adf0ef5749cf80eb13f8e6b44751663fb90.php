
<?php $__env->startSection('title', "Transactions Points"); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-0">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header ">
                        <h3 class="card-title">
                            <i class="fas fa-users mr-1"></i>
                            <h3 class="float-left"> Point Transactions</h3>
                        </h3>

                    </div>

                    <div class="card-body table-responsive p-0">
                        <table class="table table-bordered table-striped table-dark table-sm text-center" >
                            <thead>
                            <tr class="btn-dark " >
                                <th><?php echo e(__('ID')); ?></th>
                                <th><?php echo e(__('from user')); ?></th>
                                <th><?php echo e(__('To user')); ?></th>
                                <th><?php echo e(__('Points')); ?></th>
                                <th><?php echo e(__('Type')); ?></th>
                                <th><?php echo e(__('Created At')); ?></th>
                                <th><?php echo e(__('Actions')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(is_countable($pointTransactions) && count($pointTransactions) > 0): ?>
                                <?php $__currentLoopData = $pointTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pointTransaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($pointTransaction->id); ?></td>
                                        <td><?php echo e($pointTransaction->fromUser?->name ?? 'Passed User'); ?></td>
                                        <td><?php echo e($pointTransaction->toUser?->name ?? 'Passed User'); ?></td>
                                        <td><?php echo e($pointTransaction->point); ?></td>
                                        <td><?php echo e($pointTransaction->type); ?></td>
                                        <td><?php echo e($pointTransaction->created_at); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('point_transactions.destroy', $pointTransaction->id)); ?>" method="POST" style="display: inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"><?php echo e(__('Delete')); ?></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7"><?php echo e(__('No Records')); ?></td>
                                </tr>
                            </tbody>

                            <?php endif; ?>
                            <tr class="btn-dark " >
                                <th><?php echo e(__('ID')); ?></th>
                                <th><?php echo e(__('from user')); ?></th>
                                <th><?php echo e(__('To user')); ?></th>
                                <th><?php echo e(__('Points')); ?></th>
                                <th><?php echo e(__('Type')); ?></th>
                                <th><?php echo e(__('Created At')); ?></th>
                                <th><?php echo e(__('Actions')); ?></th>
                            </tr>
                        </table>
                    </div>
                                <div class="card-footer" style="height: 50px;"> <!-- Adjust height as needed -->
                            <div class="m-0" style="display: flex; justify-content: center;">
                                <?php echo e($pointTransactions->links()); ?>

                            </div>
                     </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/point_transactions/index.blade.php ENDPATH**/ ?>