<?php echo e($slot); ?>

<?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>