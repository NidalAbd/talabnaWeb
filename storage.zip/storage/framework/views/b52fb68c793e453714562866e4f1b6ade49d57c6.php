

<?php $__env->startSection('content'); ?>
    <div class="container wrapper">
        <div class="row d-flex justify-content-center">
            <div class="col-md-4 mt-5">
                <div class="card">
                    <div class="card-header">
                        <div class="row d-flex justify-content-center text-center">
                            <h2><b><?php echo e(__('Login Please')); ?></b></h2>
                        </div>
                        <br>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <label for="email" class=""><?php echo e(__('Email Address')); ?></label>
                                <div class="input-group">
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="password" class="col-form-label"><?php echo e(__('Password')); ?></label>
                                <div class="input-group">
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                                    <span class="input-group-text"><i class="bi bi-eye-fill"></i></span>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="remember"><?php echo e(__('Remember Me')); ?></label>
                                    </div>
                                    <label>
                                        <?php if(Route::has('password.request')): ?>
                                            <a class="btn btn-link" style="text-decoration: none; color: #00aa44; font-weight: bold;" href="<?php echo e(route('password.request')); ?>">
                                                <?php echo e(__('Forgot Password')); ?>

                                            </a>
                                        <?php endif; ?>
                                    </label>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="input-group">
                                    <button id="submit" type="submit" class="btn btn-secondary col-md-10 mb-2">
                                        <?php echo e(__('Login with email')); ?>

                                    </button>
                                    <span class="btn btn-primary col-md-2 mb-2">
                                        <i class="bi bi-key-fill p-2"></i>
                                    </span>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mt-5">
                <div class="card">
                    <div class="card-header">
                        <div class="row d-flex justify-content-center text-center">
                            <h2><b><?php echo e(__('Login Other Options')); ?></b></h2>
                        </div>
                        <br>
                        <form>
                            <div class="row mb-3">
                                <div class="input-group">
                                    <button type="button" class="btn btn-secondary col-md-10 mb-2">
                                        <?php echo e(__('Login with Google')); ?>

                                    </button>
                                    <span class="btn btn-primary col-md-2 mb-2">
                                        <i class="bi bi-google red p-2"></i>
                                    </span>
                                </div>
                                <div class="input-group">
                                    <button type="button" class="btn btn-secondary col-md-10 mb-2">
                                        <?php echo e(__('Login with Facebook')); ?>

                                    </button>
                                    <span class="btn btn-primary col-md-2 mb-2">
                                        <i class="bi bi-facebook p-2"></i>
                                    </span>
                                </div>
                                <div class="input-group">
                                    <button type="button" class="btn btn-secondary col-md-10 mb-2">
                                        <?php echo e(__('Login with Twitter')); ?>

                                    </button>
                                    <span class="btn btn-primary col-md-2 mb-2">
                                        <i class="bi bi-twitter p-2"></i>
                                    </span>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Projects\Laravel\TalabnaNew\resources\views/auth/login.blade.php ENDPATH**/ ?>