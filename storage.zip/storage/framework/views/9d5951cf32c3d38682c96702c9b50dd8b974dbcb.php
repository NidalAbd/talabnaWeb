<?php $__env->startSection('title', "Order"); ?>
<?php $__env->startSection('content'); ?>
<div class="p-0">
    <div class="row justify-content-center">
    <div class="col-md-12">
    <div class="card">
    <div class="card-header ">
        <h3 class="card-title">
            <i class="fas fa-users mr-1"></i>
            <h3 class="float-left"> Points Order Request</h3>
        </h3>
        <div class="card-tools">
            <ul class="nav nav-pills ml-auto">
                <li class="nav-item">
                    <form action="<?php echo e(route('purchase_points.search')); ?>" method="GET" class="input-group mt-0 input-group-sm">
                        <input type="text" class="form-control" name="search" placeholder="Search users...">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </li>
            </ul>
        </div>
    </div>

            <div class="card-body table-responsive p-0">
                <table class="table table-bordered table-striped table-dark table-sm text-center" >
                    <thead>
                    <tr class="btn-dark " >
                        <th>id</th>
                        <th>User</th>
                        <th>Role</th>
                        <th>Points</th>
                        <th>price</th>
                        <th>Total Price</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(is_countable($purchaseRequests) && count($purchaseRequests) > 0): ?>
                        <?php $__currentLoopData = $purchaseRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if($purchaseRequest->user): ?>
                                    <td><?php echo e($purchaseRequest->user->id); ?></td>
                                    <td><?php echo e($purchaseRequest->user->user_name); ?></td>
                                    <td>
                                        <?php if(count($purchaseRequest->user->roles) > 0): ?>
                                            <?php $__currentLoopData = $purchaseRequest->user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($role->name); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>
                                <?php else: ?>
                                    <td colspan="3">User Not Found</td>
                                <?php endif; ?>
                                <td><?php echo e($purchaseRequest->points_requested); ?></td>
                                <td><?php echo e($purchaseRequest->price_per_point); ?></td>
                                <td><?php echo e($purchaseRequest->total_price); ?></td>
                                <td><?php echo e($purchaseRequest->status); ?></td>
                                <td>
                                    <?php if($purchaseRequest->status == 'pending'): ?>
                                        <form action="<?php echo e(route('purchase_points.approved', $purchaseRequest)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="user_id" value="<?php echo e($purchaseRequest->user_id); ?>">
                                            <button type="submit" class="btn btn-sm btn-success">Approve</button>
                                        </form>
                                        <form action="<?php echo e(route('purchase_points.cancel', $purchaseRequest)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">Cancel</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7"><?php echo e(__('No Records')); ?></td>
                        </tr>
                    </tbody>

                <?php endif; ?>
                    <tr class="btn-dark " >
                        <th>id</th>
                        <th>User</th>
                        <th>Role</th>
                        <th>Points</th>
                        <th>price</th>
                        <th>Total Price</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </table>
            </div>
             <div class="card-footer" style="height: 50px;"> <!-- Adjust height as needed -->
                            <div class="m-0" style="display: flex; justify-content: center;">
                                <?php echo e($purchaseRequests->links()); ?>

                            </div>
                     </div>
        
           </div>
         </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/purchase_requests/index.blade.php ENDPATH**/ ?>