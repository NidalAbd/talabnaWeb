<?php $__env->startSection('title', "show User"); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-0">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header ">
                        <h3 class="card-title">
                            <i class="fas fa-users mr-1"></i>
                            Show Users
                        </h3>
                        <div class="card-tools">

                            <?php if($user->photos->count() > 0): ?>
                                <img src="<?php echo e(asset('storage/' . $user->photos->first()->src)); ?>" class="img-circle elevation-2" alt="Profile Picture" width="70">
                            <?php else: ?>
                                <img src="<?php echo e(asset('images/default-profile-picture.png')); ?>" alt="Profile Picture">

                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="card-body table-responsive p-2">
                        <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-inline">
                                <div class="form-group col-md-4">
                                    <label for="user_name">Username:</label>
                                    <input type="text" name="user_name" class="form-control col-md-12" value="<?php echo e($user->user_name); ?>" disabled>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="name">Name:</label>
                                    <input type="text" name="name" class="form-control col-md-12" value="<?php echo e($user->name); ?>" disabled>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="gender">Gender:</label>
                                    <select name="gender" class="form-control col-md-12" disabled>
                                        <option value="male" <?php echo e($user->gender == 'male' ? 'selected' : ''); ?>>Male</option>
                                        <option value="female" <?php echo e($user->gender == 'female' ? 'selected' : ''); ?>>Female</option>
                                        <option value="other" <?php echo e($user->gender == 'other' ? 'selected' : ''); ?>>Other</option>
                                    </select>
                                </div>

                            </div>
                            <div class="form-inline">
                                <div class="form-group col-md-4">
                                    <label for="date_of_birth">Date of Birth:</label>
                                    <input type="datetime-local" name="date_of_birth" class="form-control col-md-12" value="<?php echo e(date('Y-m-d H:i:s', strtotime($user->date_of_birth))); ?>" disabled>
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="location_latitudes">Latitude:</label>
                                    <input type="text" name="location_latitudes" class="form-control col-md-12" value="<?php echo e($user->location_latitudes); ?>" disabled>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="location_longitudes">Longitude:</label>
                                    <input type="text" name="location_longitudes" class="form-control col-md-12" value="<?php echo e($user->location_longitudes); ?>" disabled>
                                </div>
                            </div>
                            <div class="form-inline">
                                <div class="form-group col-md-4">
                                    <label for="phones">Phone Number:</label>
                                    <input type="text" name="phones" class="form-control col-md-12" value="<?php echo e($user->phones); ?>" disabled>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="WatsNumber">Wats Number:</label>
                                    <input type="text" name="WatsNumber" class="form-control col-md-12" value="<?php echo e($user->WatsNumber); ?>" disabled>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="city">City:</label>
                                    <select name="city" id="city" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> col-md-12" disabled>
                                        <option value="">Select city</option>
                                        <option value="القدس" <?php echo e(old('city', $user->city) === 'القدس' ? 'selected' : ''); ?>>القدس</option>
                                        <option value="شمال غزة" <?php echo e(old('city', $user->city) === 'شمال غزة' ? 'selected' : ''); ?>>شمال غزة</option>
                                        <option value="غزة" <?php echo e(old('city', $user->city) === 'غزة' ? 'selected' : ''); ?>>غزة</option>
                                        <option value="دير البلح" <?php echo e(old('city', $user->city) === 'دير البلح' ? 'selected' : ''); ?>>دير البلح</option>
                                        <option value="خان يونس" <?php echo e(old('city', $user->city) === 'خان يونس' ? 'selected' : ''); ?>>خان يونس</option>
                                        <option value="رفح" <?php echo e(old('city', $user->city) === 'رفح' ? 'selected' : ''); ?>>رفح</option>
                                        <option value="رام الله" <?php echo e(old('city', $user->city) === 'رام الله' ? 'selected' : ''); ?>>رام الله</option>
                                        <option value="الخليل" <?php echo e(old('city', $user->city) === 'الخليل' ? 'selected' : ''); ?>>الخليل</option>
                                        <option value="بيت لحم" <?php echo e(old('city', $user->city) === 'بيت لحم' ? 'selected' : ''); ?>>بيت لحم</option>
                                        <option value="نابلس" <?php echo e(old('city', $user->city) === 'نابلس' ? 'selected' : ''); ?>>نابلس</option>
                                        <option value="جنين" <?php echo e(old('city', $user->city) === 'جنين' ? 'selected' : ''); ?>>جنين</option>
                                        <option value="سلفيت" <?php echo e(old('city', $user->city) === 'سلفيت' ? 'selected' : ''); ?>>سلفيت</option>
                                        <option value="عسقلان" <?php echo e(old('city', $user->city) === 'عسقلان' ? 'selected' : ''); ?>>عسقلان</option>
                                        <option value="بئر السبع" <?php echo e(old('city', $user->city) === 'بئر السبع' ? 'selected' : ''); ?>>بئر السبع</option>
                                        <option value="طبريا" <?php echo e(old('city', $user->city) === 'طبريا' ? 'selected' : ''); ?>>طبريا</option>
                                        <option value="الناصرة" <?php echo e(old('city', $user->city) === 'الناصرة' ? 'selected' : ''); ?>>الناصرة</option>
                                        <option value="<?php echo e(old('city', $user->city) === 'صفد' ? 'selected' : ''); ?>صفد">صفد</option>
                                        <option value="<?php echo e(old('city', $user->city) === 'بيسان' ? 'selected' : ''); ?>بيسان">بيسان</option>
                                        <option value="<?php echo e(old('city', $user->city) === 'اللد' ? 'selected' : ''); ?>اللد">اللد</option>
                                        <option value="<?php echo e(old('city', $user->city) === 'الرملة' ? 'selected' : ''); ?>الرملة">الرملة</option>
                                        <option value="طولكرم<?php echo e(old('city', $user->city) === 'طولكرم' ? 'selected' : ''); ?>">طولكرم</option>
                                        <option value="<?php echo e(old('city', $user->city) === 'قلقيلية' ? 'selected' : ''); ?>قلقيلية">قلقيلية</option>
                                        <option value="عكا<?php echo e(old('city', $user->city) === 'عكا' ? 'selected' : ''); ?>">عكا</option>
                                        <option value="حيفا<?php echo e(old('city', $user->city) === 'حيفا' ? 'selected' : ''); ?>">حيفا</option>
                                        <option value="يافا<?php echo e(old('city', $user->city) === 'يافا' ? 'selected' : ''); ?>">يافا</option>
                                        <option value="<?php echo e(old('city', $user->city) === 'أريحا' ? 'selected' : ''); ?>أريحا">أريحا</option>
                                    </select>
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-inline">
                                <div class="form-group col-md-4">
                                    <label for="email">Email:</label>
                                    <input type="email" name="email" id="email" class="form-control col-md-12"  value="<?php echo e($user->email); ?>"  disabled>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="password">Password:</label>
                                    <input type="password" name="password" id="password"  class="form-control col-md-12" value="<?php echo e($user->password); ?>" disabled>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="password_confirmation">Confirm Password:</label>
                                    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control col-md-12" value="<?php echo e($user->password); ?>" disabled>
                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>


                        </form>

                        <div class="panel-heading" style="display:flex; justify-content:center;align-items:center;">

                        </div>
                    </div>

                    <div class="card-footer ">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary ">Back</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/users/show.blade.php ENDPATH**/ ?>