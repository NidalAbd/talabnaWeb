<?php $__env->startSection('title', "User Posts"); ?>
<?php $__env->startSection('contentPost'); ?>
    <div class="container">
        <?php if(count($servicePosts) > 0): ?>
            <?php $__currentLoopData = $servicePosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicePost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <div>
                                    <span class="position-sticky start-400  badge rounded-pill bg-info">
                                          <span class=""  data-service-post-id="<?php echo e($servicePost->id); ?>"><?php echo e($servicePost->category); ?></span>
                                      </span>
                                <span class="position-sticky badge rounded-pill bg-info">
                                           <span class=""><?php echo e($servicePost->sub_category); ?></span>
                                    </span>
                            </div>
                        </div>
                        <div class="card ">
                            <div class="card-header
    <?php if($servicePost->have_badge == 'عادي'): ?>
        bg-light
    <?php elseif($servicePost->have_badge == 'ذهبي'): ?>
        bg-gradient-dark
    <?php elseif($servicePost->have_badge == 'ماسي'): ?>
        bg-gray-dark
    <?php endif; ?>" >
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <div class="modal fade" id="reportUserModal" role="dialog" aria-labelledby="reportUserModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 style="color: #1b1e21;" class="modal-title"
                                                            id="reportUserModalLabel">Report User</h5>
                                                        <button type="button" class="btn btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"><i
                                                                class="fa fa-times" aria-hidden="true"></i></button>
                                                    </div>
                                                    <form method="POST"
                                                          action="<?php echo e(route('reports.store', ['reported' => 'user', 'reportedId' => $user->id ?? 1010101010])); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">
                                                            <div class="form-group">
                                                                <label style="color: #1b1e21;" for="reason">Reason for
                                                                    report</label>
                                                                <select class="form-control" name="reason" id="reason">
                                                                    <option value="Spam">Spam</option>
                                                                    <option value="Inappropriate content">Inappropriate
                                                                        Content
                                                                    </option>
                                                                    <option value="Harassment">Harassment</option>
                                                                    <option value="False information">False
                                                                        information
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Cancel
                                                            </button>
                                                            <button type="submit" class="btn btn-danger">Submit Report
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="btn-group">
                                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                            </button>
                                            <ul class="dropdown-menu" style="">
                                                <li>
                                                    <button type="button" class="btn btn-default" data-bs-toggle="modal" data-bs-target="#reportUserModal">
                                                        Report User
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                        <div>
                                            <?php if(auth()->check() && $servicePost->user->photos->count() > 0): ?>
                                                <div class="user-image">
                                                    <img src="<?php echo e(asset('storage/' . $servicePost->user->photos->first()->src)); ?>" class="img-circle" alt="Profile Picture" width="50" height="60">
                                                </div>
                                            <?php else: ?>
                                                <div class="user-image">
                                                    <img src="<?php echo e(asset('storage/photos/avatar1.png')); ?>" class="img-circle" alt="Profile Picture" width="50" height="50">
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <?php if(auth()->check()): ?>
                                                <h4>&nbsp;<?php echo e($servicePost->user->user_name); ?></h4>
                                            <?php else: ?>
                                                <h4>&nbsp;Anonymous User</h4>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="d-flex">
                                        <h5><?php echo e($servicePost->title); ?></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <p><?php echo e($servicePost->description); ?></p>
                                <div class="media-container mt-4">
                                    <?php if($servicePost->photos->count() > 0): ?>
                                        <div class="row justify-content-center">
                                            <?php $__currentLoopData = $servicePost->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-12   mb-3">
                                                    <?php
                                                        $extension = pathinfo($photo->src, PATHINFO_EXTENSION);
                                                    ?>
                                                    <div class="media-container">
                                                        <?php if(in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                                          <div class="photo-item">
                                                              <img src="<?php echo e(asset('storage/' . $photo->src)); ?>" class="img-fluid  rounded" alt="Image">
                                                          </div>
                                                        <?php elseif(in_array($extension, ['mp3', 'wav'])): ?>
                                                            <audio controls>
                                                                <source src="<?php echo e(asset('storage/' . $photo->src)); ?>" type="audio/<?php echo e($extension); ?>">
                                                                Your browser does not support the audio element.
                                                            </audio>
                                                        <?php elseif(in_array($extension, ['mp4', 'mov', 'avi', 'HIEC'])): ?>
                                                            <div class="video-container video ">
                                                                <video controls width="100%">
                                                                    <source src="<?php echo e(asset('storage/' . $photo->src)); ?>" type="video/<?php echo e($extension); ?>">
                                                                    Your browser does not support the video element.
                                                                </video>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php else: ?>
                                        <p class="no-media-text">No post photos</p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="card-footer">
                                <div class="row justify-content-between align-items-center">
                                    <div class="col-auto">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-eye icon mr-2"></i>
                                            <span class="text-secondary"><?php echo e($servicePost->view_count); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <div class="d-flex align-items-center">
                                            <a class="favorite-btn" data-post-id="<?php echo e($servicePost->id); ?>">
                                                <i class="fas <?php echo e(auth()->check() && $servicePost->isFavoritedBy(auth()->user()) ? 'text-danger' : 'text-muted'); ?> fa-heart icon mr-2"></i>
                                                <span class="favorite-count"><?php echo e($servicePost->favoritesCount()); ?></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-dollar-sign icon mr-2"></i>
                                            <span class="text-primary"><?php echo e($servicePost->price); ?> <?php echo e($servicePost->price_currency); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <div class="dropdown">
                                            <a href="#" class="text-secondary" role="button" id="reportDropdown" data-bs-toggle="dropdown"
                                               aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-h"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="reportDropdown">
                                                <button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#reportModal">
                                                    Report
                                                </button>
                                                <!-- Add more dropdown items if needed -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="modal fade" id="reportModal" tabindex="-1" aria-labelledby="reportModalLabel"
                     aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="reportModalLabel">Report Service Post</h5>
                                <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close">
                                    <i class="fa fa-times" aria-hidden="true"></i></button>
                            </div>
                            <form method="POST"
                                  action="<?php echo e(route('reports.store', ['reported' => 'service_post', 'reportedId' => $servicePost->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="reason">Reason for report</label>
                                        <select class="form-control" name="reason" id="reason">
                                            <option value="spam">Spam</option>
                                            <option value="inappropriate content">Inappropriate Content</option>
                                            <option value="harassment">Harassment</option>
                                            <option value="false information">False information</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel
                                    </button>
                                    <button type="submit" class="btn btn-danger">Submit Report</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="row justify-content-center">
                <div class="col-md-12 mb-3">
                    <div class="card ">
                        <div class="card-header">
                            <div class="row justify-content-between">
                                <div class="d-flex align-items-center">
                                    <div>
                                        <?php if($user->photos->count() > 0): ?>
                                            <img src="<?php echo e(asset('storage/' . $user->photos->first()->src)); ?>"
                                                 class="img-circle" alt="Profile Picture" width="50">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('storage/photos/avatar1.png')); ?>" class="img-circle"
                                                 alt="Profile Picture" width="50">
                                        <?php endif; ?>
                                    </div>
                                    <div>

                                        <h4><?php echo e($user->user_name); ?></h4>
                                    </div>

                                </div>
                                <div class="d-flex align-items-center">
                                </div>
                            </div>


                        </div>
                        <div class="card-body text-right d-flex justify-content-center" style="height: 257px">
                            <p><strong><?php echo e('no records'); ?></strong></p>
                            <div>
                            </div>
                        </div>
                        <div class="card-footer" style="height: 50px">
                            <div class="row justify-content-between">
                                <div>

                                </div>
                                <div>

                                </div>
                                <div>

                                </div>
                                <div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('.favorite-btn').on('click', function (e) {
                e.preventDefault();
                var postId = $(this).data('post-id');
                var favoriteBtn = $(this);
                var isFavorite = favoriteBtn.find('i').hasClass('text-danger');

                $.ajax({
                    url: '<?php echo e(route('favorites.store')); ?>',
                    method: 'POST',
                    data: {
                        post_id: postId,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function (data) {
                        var count = data.count;
                        var isFavorited = data.is_favorited;

                        if (isFavorited) {
                            favoriteBtn.find('i').removeClass('text-muted').addClass('text-danger');
                        } else {
                            favoriteBtn.find('i').removeClass('text-danger').addClass('text-muted');
                        }

                        favoriteBtn.find('.favorite-count').text(count);
                    }
                });
            });

// Define a debounce function
            function debounce(func, wait, immediate) {
                var timeout;
                return function () {
                    var context = this, args = arguments;
                    var later = function () {
                        timeout = null;
                        if (!immediate) func.apply(context, args);
                    };
                    var callNow = immediate && !timeout;
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                    if (callNow) func.apply(context, args);
                };
            }

            // Use the debounce function to delay the execution of the code
            $(window).on('scroll', debounce(function () {
                $('.service-post').each(function () {
                    var servicePostElement = $(this).get(0);
                    var servicePostBottom = servicePostElement.offsetTop + servicePostElement.offsetHeight;
                    var windowHeight = window.innerHeight;
                    var windowBottom = window.scrollY + windowHeight;

                    if (windowBottom >= servicePostBottom) {
                        // Get the servicePost ID from the data attribute
                        var servicePostId = $(servicePostElement).data('service-post-id');

                        // Get the CSRF token from the page's meta tags
                        var csrfToken = $('meta[name="csrf-token"]').attr('content');

                        // Make an AJAX request to increment the view count for this service post
                        $.ajax({
                            url: '<?php echo e(route('inViewCount.view', ':id')); ?>'.replace(':id', servicePostId),
                            type: 'POST',
                            data: {
                                _token: csrfToken
                            },
                            success: function (response) {
                                console.log(response);
                            }
                        });
                    }
                });
            }, 500));

            $.each(categories, function (index, category) {
                var categoryBtn = $('<button>')
                    .addClass('category-btn btn btn-secondary')
                    .data('category', category.name)
                    .text(category.name + ' (' + category.service_posts_count + ')');
                categoryContainer.append(categoryBtn);
            });

            $('.category-btn').on('click', function () {
                alert('wadwad');
                var category = $(this).data('category');
                $.ajax({
                    url: '<?php echo e(route('sub-categories.category', ':category')); ?>'.replace(':category', category),
                    success: function (subCategories) {
                        var subcategoryContainer = $('.subcategory-container');
                        subcategoryContainer.empty();
                        $.each(subCategories, function (index, subCategory) {
                            var subcategoryBtn = $('<button>')
                                .addClass('subcategory-btn btn btn-secondary')
                                .data('subcategory', subCategory.name)
                                .text(subCategory.name + ' (' + subCategory.service_posts_count + ')');
                            subcategoryContainer.append(subcategoryBtn);
                        });
                    }
                });
            });

            $(document).on('click', '.subcategory-btn', function () {
                var subCategory = $(this).data('subcategory');
                $.ajax({
                    url: '<?php echo e(route('service-posts.category', ':category')); ?>'.replace(':category', subCategory),

                    success: function (servicePosts) {
                        // Update the service post container with the new data
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u693675641/domains/talbna.cloud/public_html/resources/views/service_posts/post_page.blade.php ENDPATH**/ ?>